/* BYCO_Logico: */

CREATE TABLE Candidato (
    Cand_COD INTEGER (16) PRIMARY KEY,
    Cand_Nome VARCHAR (255),
    Cand_CPF VARCHAR (14) UNIQUE,
    Cand_RG VARCHAR (12) UNIQUE,
    Cand_DataNascimento INTEGER (8),
    Cand_Sexo VARCHAR (9),
    Cand_TelefoneCelular INTEGER (11),
    Cand_Escolaridade VARCHAR (255),
    Cand_Atuacao VARCHAR (255),
    Cand_Observacao VARCHAR (255),
    Cand_PaisRegiao VARCHAR (255),
    Cand_Estado VARCHAR (255),
    Cand_Cidade VARCHAR (255),
    Cand_Bairro VARCHAR (255),
    Cand_Rua VARCHAR (255)
);

CREATE TABLE Empresa (
    Emp_COD INTEGER (19) PRIMARY KEY,
    Emp_Nome VARCHAR (255),
    Emp_NomeFantasia VARCHAR (255),
    Emp_TipoNegocio VARCHAR (255),
    Emp_TelefoneComercial VARCHAR (10),
    Emp_PaisRegiao VARCHAR (255),
    Emp_Estado VARCHAR (255),
    Emp_Cidade VARCHAR (255),
    Emp_Bairro VARCHAR (255),
    Emp_Rua VARCHAR (255),
    Emp_RuaNumero INTEGER (100),
    Emp_DataFundacao VARCHAR (8),
    Emp_CNPJ VARCHAR (18) UNIQUE
);

CREATE TABLE User_Candidato (
    Cand_Email VARCHAR (255) PRIMARY KEY,
    Cand_UserLogin VARCHAR (255),
    Cand_Senha VARCHAR (255)
);

CREATE TABLE User_Empresa (
    Emp_Email VARCHAR (255) PRIMARY KEY,
    Emp_UserLogin VARCHAR (255),
    Emp_Senha VARCHAR (255)
);

CREATE TABLE Vaga (
    fk_Empresa_Emp_COD INTEGER (19),
    Vag_COD INTEGER (10) PRIMARY KEY,
    Vag_Nome VARCHAR (255),
    Vag_TipoVaga VARCHAR (255),
    Vag_TipoFuncionarioNecessario VARCHAR (255),
    Vag_CargaHoraria VARCHAR (255),
    Vag_PeriodoNecessario VARCHAR (255),
    Vag_Salario VARCHAR (255),
    Vag_Observacao VARCHAR (255)
);

CREATE TABLE LoginC (
    fk_Candidato_Cand_COD INTEGER (16),
    fk_User_Candidato_Cand_Email VARCHAR (255)
);

CREATE TABLE LoginE (
    fk_Empresa_Emp_COD INTEGER (19),
    fk_User_Empresa_Emp_Email VARCHAR (255)
);
 
ALTER TABLE Vaga ADD CONSTRAINT FK_Vaga_2
    FOREIGN KEY (fk_Empresa_Emp_COD)
    REFERENCES Empresa (Emp_COD)
    ON DELETE RESTRICT;
 
ALTER TABLE Vaga ADD CONSTRAINT FK_Vaga_3
    FOREIGN KEY (fk_Candidato_Cand_COD)
    REFERENCES Candidato (Cand_COD)
    ON DELETE RESTRICT;
 
ALTER TABLE LoginC ADD CONSTRAINT FK_LoginC_1
    FOREIGN KEY (fk_Candidato_Cand_COD)
    REFERENCES Candidato (Cand_COD)
    ON DELETE RESTRICT;
 
ALTER TABLE LoginC ADD CONSTRAINT FK_LoginC_2
    FOREIGN KEY (fk_User_Candidato_Cand_Email)
    REFERENCES User_Candidato (Cand_Email)
    ON DELETE RESTRICT;
 
ALTER TABLE LoginE ADD CONSTRAINT FK_LoginE_1
    FOREIGN KEY (fk_Empresa_Emp_COD)
    REFERENCES Empresa (Emp_COD)
    ON DELETE RESTRICT;
 
ALTER TABLE LoginE ADD CONSTRAINT FK_LoginE_2
    FOREIGN KEY (fk_User_Empresa_Emp_Email)
    REFERENCES User_Empresa (Emp_Email)
    ON DELETE RESTRICT;