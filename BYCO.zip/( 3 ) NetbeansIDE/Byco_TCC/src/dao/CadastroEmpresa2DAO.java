/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import factory.ConnectionFactory;
import modelo.CadastroEmpresa2;
import java.sql.*;
import java.sql.PreparedStatement;
public class CadastroEmpresa2DAO { 
    private Connection connection;
  Long Emp_COD;
  String Emp_Nome;
  String Emp_NomeFantasia;
  String Emp_TipoNegocio;
  String Emp_TelefoneComercial;
  String Emp_PaisRegiao;
  String Emp_Estado;
  String Emp_Cidade;
  String Emp_Bairro;
  String Emp_Rua;
  String Emp_RuaNumero;
  String Emp_DataFundacao;
  String Emp_CNPJ;
public CadastroEmpresa2DAO(){
this.connection = new ConnectionFactory().getConnection();
    } 
    public void adiciona(CadastroEmpresa2 CadastroEmpresa2){ 
        String sql = "INSERT INTO Empresa(Emp_Nome,Emp_NomeFantasia,Emp_TipoNegocio,Emp_TelefoneComercial,Emp_PaisRegiao,Emp_Estado,Emp_Cidade,Emp_Bairro,Emp_Rua,Emp_RuaNumero,Emp_DataFundacao,Emp_CNPJ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
        try { 
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, CadastroEmpresa2.getEmp_Nome());
            stmt.setString(2, CadastroEmpresa2.getEmp_NomeFantasia());
            stmt.setString(3, CadastroEmpresa2.getEmp_TipoNegocio());
            stmt.setString(4, CadastroEmpresa2.getEmp_TelefoneComercial());
            stmt.setString(5, CadastroEmpresa2.getEmp_PaisRegiao());
            stmt.setString(6, CadastroEmpresa2.getEmp_Estado());
            stmt.setString(7, CadastroEmpresa2.getEmp_Cidade());
            stmt.setString(8, CadastroEmpresa2.getEmp_Bairro());
            stmt.setString(9, CadastroEmpresa2.getEmp_Rua());
            stmt.setString(10, CadastroEmpresa2.getEmp_RuaNumero());
            stmt.setString(11, CadastroEmpresa2.getEmp_DataFundacao());
            stmt.setString(12, CadastroEmpresa2.getEmp_CNPJ());
            stmt.execute();
            stmt.close();
        } 
        catch (SQLException u) { 
            throw new RuntimeException(u);
        } 
        
    }
}