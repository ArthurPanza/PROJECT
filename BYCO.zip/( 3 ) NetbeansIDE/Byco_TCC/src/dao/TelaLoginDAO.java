/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import factory.ConnectionFactory;
import modelo.TelaLogin;
import java.sql.*;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
/**
 *
 * @author senai
 */
public class TelaLoginDAO {
  private Connection connection;
  String UC_UserLogin;
  String UC_Senha;
/**
 *
 * @author senai
 */
public TelaLoginDAO() {
    this.connection = new ConnectionFactory().getConnection();
}
         public void adiciona(TelaLogin TelaLogin){ 
        String sql = "SELECT User_Candidato WHERE UC_UserLogin AND UC_Senha VALUE (?,?)";
        try { 
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, TelaLogin.getUC_UserLogin());
            stmt.setString(2, TelaLogin.getUC_Senha());
            stmt.execute();
            stmt.close();
        } 
        catch (SQLException u) { 
            throw new RuntimeException(u);
        } 
        
    }

}
