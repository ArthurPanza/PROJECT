/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author senai
 */
public class CadastroEmpresa2 {
  Long Emp_COD;
  String Emp_Nome ;
  String Emp_NomeFantasia;
  String Emp_TipoNegocio;
  String Emp_TelefoneComercial;
  String Emp_PaisRegiao;
  String Emp_Estado;
  String Emp_Cidade;
  String Emp_Bairro;
  String Emp_Rua;
  String Emp_RuaNumero;
  String Emp_DataFundacao;
  String Emp_CNPJ;

    public Long getEmp_COD() {
        return Emp_COD;
    }

    public void setEmp_COD(Long Emp_COD) {
        this.Emp_COD = Emp_COD;
    }

    public String getEmp_Nome() {
        return Emp_Nome;
    }

    public void setEmp_Nome(String Emp_Nome) {
        this.Emp_Nome = Emp_Nome;
    }

    public String getEmp_NomeFantasia() {
        return Emp_NomeFantasia;
    }

    public void setEmp_NomeFantasia(String Emp_NomeFantasia) {
        this.Emp_NomeFantasia = Emp_NomeFantasia;
    }

    public String getEmp_TipoNegocio() {
        return Emp_TipoNegocio;
    }

    public void setEmp_TipoNegocio(String Emp_TipoNegocio) {
        this.Emp_TipoNegocio = Emp_TipoNegocio;
    }

    public String getEmp_TelefoneComercial() {
        return Emp_TelefoneComercial;
    }

    public void setEmp_TelefoneComercial(String Emp_TelefoneComercial) {
        this.Emp_TelefoneComercial = Emp_TelefoneComercial;
    }

    public String getEmp_PaisRegiao() {
        return Emp_PaisRegiao;
    }

    public void setEmp_PaisRegiao(String Emp_PaisRegiao) {
        this.Emp_PaisRegiao = Emp_PaisRegiao;
    }

    public String getEmp_Estado() {
        return Emp_Estado;
    }

    public void setEmp_Estado(String Emp_Estado) {
        this.Emp_Estado = Emp_Estado;
    }

    public String getEmp_Cidade() {
        return Emp_Cidade;
    }

    public void setEmp_Cidade(String Emp_Cidade) {
        this.Emp_Cidade = Emp_Cidade;
    }

    public String getEmp_Bairro() {
        return Emp_Bairro;
    }

    public void setEmp_Bairro(String Emp_Bairro) {
        this.Emp_Bairro = Emp_Bairro;
    }

    public String getEmp_Rua() {
        return Emp_Rua;
    }

    public void setEmp_Rua(String Emp_Rua) {
        this.Emp_Rua = Emp_Rua;
    }

    public String getEmp_RuaNumero() {
        return Emp_RuaNumero;
    }

    public void setEmp_RuaNumero(String Emp_RuaNumero) {
        this.Emp_RuaNumero = Emp_RuaNumero;
    }

    public String getEmp_DataFundacao() {
        return Emp_DataFundacao;
    }

    public void setEmp_DataFundacao(String Emp_DataFundacao) {
        this.Emp_DataFundacao = Emp_DataFundacao;
    }

    public String getEmp_CNPJ() {
        return Emp_CNPJ;
    }

    public void setEmp_CNPJ(String Emp_CNPJ) {
        this.Emp_CNPJ = Emp_CNPJ;
    }
  
  
 }
