/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author senai
 */
public class CadastroCandidato2 {
   Long Cand_COD;
   String Cand_Nome;
   String Cand_CPF;
   String Cand_RG;
   String Cand_DataNascimento;
   String Cand_Sexo;
   String Cand_TelefoneCelular;
   String Cand_Escolaridade;
   String Cand_Atuacao;
   String Cand_Observacao;
   String Cand_PaisRegiao;
   String Cand_Estado;
   String Cand_Cidade;
   String Cand_Bairro;
   String Cand_Rua;

    public Long getCand_COD() {
        return Cand_COD;
    }

    public void setCand_COD(Long Cand_COD) {
        this.Cand_COD = Cand_COD;
    }

    public String getCand_Nome() {
        return Cand_Nome;
    }

    public void setCand_Nome(String Cand_Nome) {
        this.Cand_Nome = Cand_Nome;
    }

    public String getCand_CPF() {
        return Cand_CPF;
    }

    public void setCand_CPF(String Cand_CPF) {
        this.Cand_CPF = Cand_CPF;
    }

    public String getCand_RG() {
        return Cand_RG;
    }

    public void setCand_RG(String Cand_RG) {
        this.Cand_RG = Cand_RG;
    }

    public String getCand_DataNascimento() {
        return Cand_DataNascimento;
    }

    public void setCand_DataNascimento(String Cand_DataNascimento) {
        this.Cand_DataNascimento = Cand_DataNascimento;
    }

    public String getCand_Sexo() {
        return Cand_Sexo;
    }

    public void setCand_Sexo(String Cand_Sexo) {
        this.Cand_Sexo = Cand_Sexo;
    }

    public String getCand_TelefoneCelular() {
        return Cand_TelefoneCelular;
    }

    public void setCand_TelefoneCelular(String Cand_TelefoneCelular) {
        this.Cand_TelefoneCelular = Cand_TelefoneCelular;
    }

    public String getCand_Escolaridade() {
        return Cand_Escolaridade;
    }

    public void setCand_Escolaridade(String Cand_Escolaridade) {
        this.Cand_Escolaridade = Cand_Escolaridade;
    }

    public String getCand_Atuacao() {
        return Cand_Atuacao;
    }

    public void setCand_Atuacao(String Cand_Atuacao) {
        this.Cand_Atuacao = Cand_Atuacao;
    }

    public String getCand_Observacao() {
        return Cand_Observacao;
    }

    public void setCand_Observacao(String Cand_Observacao) {
        this.Cand_Observacao = Cand_Observacao;
    }

    public String getCand_PaisRegiao() {
        return Cand_PaisRegiao;
    }

    public void setCand_PaisRegiao(String Cand_PaisRegiao) {
        this.Cand_PaisRegiao = Cand_PaisRegiao;
    }

    public String getCand_Estado() {
        return Cand_Estado;
    }

    public void setCand_Estado(String Cand_Estado) {
        this.Cand_Estado = Cand_Estado;
    }

    public String getCand_Cidade() {
        return Cand_Cidade;
    }

    public void setCand_Cidade(String Cand_Cidade) {
        this.Cand_Cidade = Cand_Cidade;
    }

    public String getCand_Bairro() {
        return Cand_Bairro;
    }

    public void setCand_Bairro(String Cand_Bairro) {
        this.Cand_Bairro = Cand_Bairro;
    }

    public String getCand_Rua() {
        return Cand_Rua;
    }

    public void setCand_Rua(String Cand_Rua) {
        this.Cand_Rua = Cand_Rua;
    }
   
   
}
