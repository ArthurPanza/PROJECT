/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author senai
 */
public class TelaLogin {
     String UC_Email;
     String UC_UserLogin;
     String UC_Senha;

    public String getUC_Email() {
        return UC_Email;
    }

    public void setUC_Email(String UC_Email) {
        this.UC_Email = UC_Email;
    }

    public String getUC_UserLogin() {
        return UC_UserLogin;
    }

    public void setUC_UserLogin(String UC_UserLogin) {
        this.UC_UserLogin = UC_UserLogin;
    }

    public String getUC_Senha() {
        return UC_Senha;
    }

    public void setUC_Senha(String UC_Senha) {
        this.UC_Senha = UC_Senha;
    }

    
     
}


