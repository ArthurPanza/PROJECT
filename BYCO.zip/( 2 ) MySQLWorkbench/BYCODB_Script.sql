CREATE DATABASE byco_db;
USE byco_db;

CREATE TABLE User_Candidato (
    UC_Email VARCHAR (255) PRIMARY KEY,
    UC_UserLogin VARCHAR (255),
    UC_Senha VARCHAR (255)
);

CREATE TABLE Candidato (
    Cand_COD INTEGER (16) PRIMARY KEY auto_increment,
    Cand_Nome VARCHAR (255),
    Cand_CPF VARCHAR (14) UNIQUE,
    Cand_RG VARCHAR (12) UNIQUE,
    Cand_DataNascimento VARCHAR (45),
    Cand_Sexo VARCHAR (9),
    Cand_TelefoneCelular VARCHAR (20),
    Cand_Escolaridade VARCHAR (255),
    Cand_Atuacao VARCHAR (255),
    Cand_Observacao VARCHAR (255),
    Cand_PaisRegiao VARCHAR (255),
    Cand_Estado VARCHAR (255),
    Cand_Cidade VARCHAR (255),
    Cand_Bairro VARCHAR (255),
    Cand_Rua VARCHAR (255)
);

CREATE TABLE User_Empresa (
    UE_Email VARCHAR (255) PRIMARY KEY,
    UE_UserLogin VARCHAR (255),
    UE_Senha VARCHAR (255)
);

CREATE TABLE Empresa (
    Emp_COD INTEGER (19) PRIMARY KEY AUTO_INCREMENT,
    Emp_Nome VARCHAR (255),
    Emp_NomeFantasia VARCHAR (255),
    Emp_TipoNegocio VARCHAR (255),
    Emp_TelefoneComercial VARCHAR (20),
    Emp_PaisRegiao VARCHAR (255),
    Emp_Estado VARCHAR (255),
    Emp_Cidade VARCHAR (255),
    Emp_Bairro VARCHAR (255),
    Emp_Rua VARCHAR (255),
    Emp_RuaNumero INTEGER (100),
	Emp_CNPJ VARCHAR (18) UNIQUE,
    Emp_DataFundacao VARCHAR (35)
);

CREATE TABLE LoginC (
    Cand_COD INTEGER (16) ,
    UC_Email VARCHAR (255),
    FOREIGN KEY (Cand_COD) REFERENCES Candidato (Cand_COD) ON DELETE RESTRICT,
	FOREIGN KEY (UC_Email) REFERENCES User_Candidato (UC_Email) ON DELETE RESTRICT
);

CREATE TABLE LoginE (
    Emp_COD INTEGER (19),
    UE_Email VARCHAR (255),
	FOREIGN KEY (Emp_COD) REFERENCES Empresa (Emp_COD) ON DELETE RESTRICT,
	FOREIGN KEY (UE_Email) REFERENCES User_Empresa (UE_Email) ON DELETE RESTRICT
);

CREATE TABLE Vaga (
    Vag_COD INTEGER (10) PRIMARY KEY auto_increment,
    Vag_Nome VARCHAR (255),
    Vag_TipoVaga VARCHAR (255),
    Vag_TipoFuncionarioNecessario VARCHAR (255),
    Vag_CargaHoraria VARCHAR (255),
    Vag_PeriodoNecessario VARCHAR (255),
    Vag_Salario VARCHAR (255),
    Vag_Observacao VARCHAR (255)
);
