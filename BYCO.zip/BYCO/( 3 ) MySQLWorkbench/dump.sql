CREATE DATABASE  IF NOT EXISTS `byco_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `byco_db`;
-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: byco_db
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `candidato`
--

DROP TABLE IF EXISTS `candidato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidato` (
  `Cand_COD` int NOT NULL AUTO_INCREMENT,
  `Cand_Nome` varchar(255) DEFAULT NULL,
  `Cand_CPF` varchar(14) DEFAULT NULL,
  `Cand_RG` varchar(12) DEFAULT NULL,
  `Cand_DataNascimento` varchar(45) DEFAULT NULL,
  `Cand_Sexo` varchar(9) DEFAULT NULL,
  `Cand_TelefoneCelular` varchar(20) DEFAULT NULL,
  `Cand_Escolaridade` varchar(255) DEFAULT NULL,
  `Cand_Atuacao` varchar(255) DEFAULT NULL,
  `Cand_Observacao` varchar(255) DEFAULT NULL,
  `Cand_PaisRegiao` varchar(255) DEFAULT NULL,
  `Cand_Estado` varchar(255) DEFAULT NULL,
  `Cand_Cidade` varchar(255) DEFAULT NULL,
  `Cand_Bairro` varchar(255) DEFAULT NULL,
  `Cand_Rua` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Cand_COD`),
  UNIQUE KEY `Cand_CPF` (`Cand_CPF`),
  UNIQUE KEY `Cand_RG` (`Cand_RG`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidato`
--

LOCK TABLES `candidato` WRITE;
/*!40000 ALTER TABLE `candidato` DISABLE KEYS */;
INSERT INTO `candidato` VALUES (1,'Arthur','211.207.310-27','32.131.232-1','Fri Oct 20 00:00:00 BRST 2000','Masculino','(21) 98120-7310','Ensino Médio Completo','ADS','','SUL','PR','Londrina','Murilp','Vak'),(3,'Alesobson','678.232.323-23','11.432.686-9','Sun Oct 07 00:00:00 BRT 1990','Masculino','(12) 93244-4231','Ensino Médio Completo','ADS','Casado e feliz.','SUL','SC','Florianopolis','Arcanjo','Cavanco'),(4,'Alberto Isaurus','198.101.256-31','10.295.312-9','Tue Feb 09 00:00:00 BRST 1999','Masculino','(10) 99267-3102','Ensino Superior Completo','Artes','Artista Freelancer','SUDESTE','SP','Osasco','Ciclo de Máquinas','Almirante'),(7,'AsimoveGEO','175.101.256-31','96.709.692-1','Mon Nov 19 00:00:00 BRT 1979','Masculino','(11) 99846-3627','Pós-Graduação','Comunicação','Radioamador e Comunicador','SUL','RS','Pelotas','Kalash','Nikov'),(8,'Lucille Assamtis','754.658.597-06','75.463.237-6','Sun Apr 01 18:53:53 BRT 1984','Feminino','(57) 96432-5366','Ensino Superior Completo','Artes','Artista e Comunicadora.','SUDESTE','SP','Osasco','Iberê','Lajuslava');
/*!40000 ALTER TABLE `candidato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS `empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empresa` (
  `Emp_COD` int NOT NULL AUTO_INCREMENT,
  `Emp_Nome` varchar(255) DEFAULT NULL,
  `Emp_NomeFantasia` varchar(255) DEFAULT NULL,
  `Emp_TipoNegocio` varchar(255) DEFAULT NULL,
  `Emp_TelefoneComercial` varchar(20) DEFAULT NULL,
  `Emp_PaisRegiao` varchar(255) DEFAULT NULL,
  `Emp_Estado` varchar(255) DEFAULT NULL,
  `Emp_Cidade` varchar(255) DEFAULT NULL,
  `Emp_Bairro` varchar(255) DEFAULT NULL,
  `Emp_Rua` varchar(255) DEFAULT NULL,
  `Emp_RuaNumero` int DEFAULT NULL,
  `Emp_CNPJ` varchar(18) DEFAULT NULL,
  `Emp_DataFundacao` varchar(35) DEFAULT NULL,
  PRIMARY KEY (`Emp_COD`),
  UNIQUE KEY `Emp_CNPJ` (`Emp_CNPJ`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresa`
--

LOCK TABLES `empresa` WRITE;
/*!40000 ALTER TABLE `empresa` DISABLE KEYS */;
INSERT INTO `empresa` VALUES (1,'Pedreira da Augusta','Pedreira Espetacular Almeida','Empacotador','(34) 3412-3321','Sudeste','SP','Osasco','Augusta       ','Almirante B',32,'123329848293','Mon Aug 14 00:00:00 BRT 2000'),(2,'TeleLojas','TeleLojas Plox','Atendente','(83) 8210-9230','Sudeste','RJ','Rio de Janeiro','Cnjt Hab B    ','União Soviética',12,'069313196598','Sun Dec 30 00:00:00 BRST 2012'),(3,'ThinkMindProductions','ThinkMindProductions Oficial ','Linguista','(81) 7821-2321','Sul','SC','Pelotas','Luislava      ','Takirov',71,'962241104458','Sat Jan 28 00:00:00 BRST 2006'),(4,'TransAlmeida Sul','Transportadora Almeida Sul','Empacotador','(98) 2121-7821','Sul','PR','Londrina','Gleba Palhano ','Coneviche',29,'767279245878','Mon Apr 07 00:00:00 BRT 2008'),(5,'MicreEmpreendedoraLORD','Microempreendedora LORD','Auxiliares','(76) 5437-8942','Sul','PR','Rolandia','Degladiadores ','Rua Freire',99,'3212312214512','Tue Feb 27 18:57:45 BRT 1979');
/*!40000 ALTER TABLE `empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loginc`
--

DROP TABLE IF EXISTS `loginc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loginc` (
  `Cand_COD` int DEFAULT NULL,
  `UC_Email` varchar(255) DEFAULT NULL,
  KEY `Cand_COD` (`Cand_COD`),
  KEY `UC_Email` (`UC_Email`),
  CONSTRAINT `loginc_ibfk_1` FOREIGN KEY (`Cand_COD`) REFERENCES `candidato` (`Cand_COD`) ON DELETE RESTRICT,
  CONSTRAINT `loginc_ibfk_2` FOREIGN KEY (`UC_Email`) REFERENCES `user_candidato` (`UC_Email`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loginc`
--

LOCK TABLES `loginc` WRITE;
/*!40000 ALTER TABLE `loginc` DISABLE KEYS */;
/*!40000 ALTER TABLE `loginc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logine`
--

DROP TABLE IF EXISTS `logine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logine` (
  `Emp_COD` int DEFAULT NULL,
  `UE_Email` varchar(255) DEFAULT NULL,
  KEY `Emp_COD` (`Emp_COD`),
  KEY `UE_Email` (`UE_Email`),
  CONSTRAINT `logine_ibfk_1` FOREIGN KEY (`Emp_COD`) REFERENCES `empresa` (`Emp_COD`) ON DELETE RESTRICT,
  CONSTRAINT `logine_ibfk_2` FOREIGN KEY (`UE_Email`) REFERENCES `user_empresa` (`UE_Email`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logine`
--

LOCK TABLES `logine` WRITE;
/*!40000 ALTER TABLE `logine` DISABLE KEYS */;
/*!40000 ALTER TABLE `logine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_candidato`
--

DROP TABLE IF EXISTS `user_candidato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_candidato` (
  `UC_Email` varchar(255) NOT NULL,
  `UC_UserLogin` varchar(255) DEFAULT NULL,
  `UC_Senha` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`UC_Email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_candidato`
--

LOCK TABLES `user_candidato` WRITE;
/*!40000 ALTER TABLE `user_candidato` DISABLE KEYS */;
INSERT INTO `user_candidato` VALUES ('albertoisaurus@gmail.com','Alberto Isaurus','isaurus9900'),('alesob1991@yahoo.com.br','Alesobson','aleale123'),('artyompanzadivision@gmail.com','artyom','123'),('asimovi@vk.com','AsimoveGEO','V9K2Gosk1'),('lucilleassamtis@gmail.com','LucilleAssamtis','LA1984');
/*!40000 ALTER TABLE `user_candidato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_empresa`
--

DROP TABLE IF EXISTS `user_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_empresa` (
  `UE_Email` varchar(255) NOT NULL,
  `UE_UserLogin` varchar(255) DEFAULT NULL,
  `UE_Senha` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`UE_Email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_empresa`
--

LOCK TABLES `user_empresa` WRITE;
/*!40000 ALTER TABLE `user_empresa` DISABLE KEYS */;
INSERT INTO `user_empresa` VALUES ('micreempreendedoralord@yahoo.com','MicreEmpreendedoraLord','MEL0RD'),('pedreiradaaugusta@gmail.com','PedreiraAugusta','19212000'),('telelojas@yahoo.com.br','TeleLojas','TL91293'),('thinkminddigital@gmail.com','ThinkMindProductions','TMProds'),('transportadorasalmeida@yahoo.com.br','TransAlmeida','TSAL226');
/*!40000 ALTER TABLE `user_empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vaga`
--

DROP TABLE IF EXISTS `vaga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vaga` (
  `Vag_COD` int NOT NULL AUTO_INCREMENT,
  `Vag_Nome` varchar(255) DEFAULT NULL,
  `Vag_TipoVaga` varchar(255) DEFAULT NULL,
  `Vag_TipoFuncionarioNecessario` varchar(255) DEFAULT NULL,
  `Vag_CargaHoraria` varchar(255) DEFAULT NULL,
  `Vag_PeriodoNecessario` varchar(255) DEFAULT NULL,
  `Vag_Salario` varchar(255) DEFAULT NULL,
  `Vag_Observacao` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Vag_COD`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vaga`
--

LOCK TABLES `vaga` WRITE;
/*!40000 ALTER TABLE `vaga` DISABLE KEYS */;
INSERT INTO `vaga` VALUES (1,'Empacotador para Transportadora','Empacotamento','Auxiliar','120hrs','Manhã','R$1.500','Necessário que tenha meio de transporte.'),(2,'Segurança de Guarida','Segurança Pública','Instruído','200hrs','Noite','R$1750','Portador de Arma de Fogo.'),(3,'Auxiliar de Administração','Administração','Provisório','190hrs','Tarde','R$1.900',''),(4,'Office Boy','Escritório','Provisória','140hrs','Manhã','R$1.400',''),(5,'Professor de Física','Ensino','Provisória','240hrs','Tarde','R$1.600','Detalhes resolver com contato com a empresa.');
/*!40000 ALTER TABLE `vaga` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-11 19:19:24
