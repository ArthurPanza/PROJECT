SELECT * FROM byco_db.user_candidato;
SELECT * FROM byco_db.candidato;
SELECT * FROM byco_db.user_empresa;
SELECT * FROM byco_db.empresa;
SELECT * FROM byco_db.vaga;