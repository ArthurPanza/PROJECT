/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author senai
 */
public class CadastroEmpresa1 {
  String UE_Email;
  String UE_UserLogin;
  String UE_Senha;

    public String getUE_Email() {
        return UE_Email;
    }

    public void setUE_Email(String UE_Email) {
        this.UE_Email = UE_Email;
    }

    public String getUE_UserLogin() {
        return UE_UserLogin;
    }

    public void setUE_UserLogin(String UE_UserLogin) {
        this.UE_UserLogin = UE_UserLogin;
    }

    public String getUE_Senha() {
        return UE_Senha;
    }

    public void setUE_Senha(String UE_Senha) {
        this.UE_Senha = UE_Senha;
    }

   
}
