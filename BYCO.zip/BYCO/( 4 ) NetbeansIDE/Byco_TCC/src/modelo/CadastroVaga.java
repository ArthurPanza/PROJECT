/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author artyo
 */
public class CadastroVaga {
    long Vag_COD;
    String Vag_Nome;
    String Vag_TipoVaga;
    String Vag_TipoFuncionarioNecessario;
    String Vag_CargaHoraria;
    String Vag_PeriodoNecessario;
    String Vag_Salario;
    String Vag_Observacao;

    public long getVag_COD() {
        return Vag_COD;
    }

    public void setVag_COD(long Vag_COD) {
        this.Vag_COD = Vag_COD;
    }

    public String getVag_Nome() {
        return Vag_Nome;
    }

    public void setVag_Nome(String Vag_Nome) {
        this.Vag_Nome = Vag_Nome;
    }

    public String getVag_TipoVaga() {
        return Vag_TipoVaga;
    }

    public void setVag_TipoVaga(String Vag_TipoVaga) {
        this.Vag_TipoVaga = Vag_TipoVaga;
    }

    public String getVag_TipoFuncionarioNecessario() {
        return Vag_TipoFuncionarioNecessario;
    }

    public void setVag_TipoFuncionarioNecessario(String Vag_TipoFuncionarioNecessario) {
        this.Vag_TipoFuncionarioNecessario = Vag_TipoFuncionarioNecessario;
    }

    public String getVag_CargaHoraria() {
        return Vag_CargaHoraria;
    }

    public void setVag_CargaHoraria(String Vag_CargaHoraria) {
        this.Vag_CargaHoraria = Vag_CargaHoraria;
    }

    public String getVag_PeriodoNecessario() {
        return Vag_PeriodoNecessario;
    }

    public void setVag_PeriodoNecessario(String Vag_PeriodoNecessario) {
        this.Vag_PeriodoNecessario = Vag_PeriodoNecessario;
    }

    public String getVag_Salario() {
        return Vag_Salario;
    }

    public void setVag_Salario(String Vag_Salario) {
        this.Vag_Salario = Vag_Salario;
    }

    public String getVag_Observacao() {
        return Vag_Observacao;
    }

    public void setVag_Observacao(String Vag_Observacao) {
        this.Vag_Observacao = Vag_Observacao;
    }
    
    
}
