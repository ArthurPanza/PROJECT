/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import factory.ConnectionFactory;
import modelo.CadastroEmpresa1;
import java.sql.*;
import java.sql.PreparedStatement;
public class CadastroEmpresa1DAO { 
    private Connection connection;
    String UE_Email;
    String UE_UserLogin;
    String UE_Senha;
    
public CadastroEmpresa1DAO(){
this.connection = new ConnectionFactory().getConnection();
    }

    public void adiciona(CadastroEmpresa1 CadastroEmpresa1){ 
        String sql = "INSERT INTO User_Empresa(UE_Email,UE_UserLogin,UE_Senha) VALUES(?,?,?)";
        try { 
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, CadastroEmpresa1.getUE_Email());
            stmt.setString(2, CadastroEmpresa1.getUE_UserLogin());
            stmt.setString(3, CadastroEmpresa1.getUE_Senha());
            stmt.execute();
            stmt.close();
        } 
        catch (SQLException u) { 
            throw new RuntimeException(u);
        } 
        
    }
    
}
