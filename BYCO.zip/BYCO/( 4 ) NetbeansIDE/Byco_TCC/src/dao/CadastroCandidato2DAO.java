/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import factory.ConnectionFactory;
import modelo.CadastroCandidato2;
import java.sql.*;
import java.sql.PreparedStatement;
import modelo.CadastroCandidato2;

public class CadastroCandidato2DAO {
    private Connection connection;
   Long Cand_COD;
   String Cand_Nome;
   String Cand_CPF;
   String Cand_RG;
   String Cand_DataNascimento;
   String Cand_Sexo;
   String Cand_TelefoneCelular;
   String Cand_Escolaridade;
   String Cand_Atuacao;
   String Cand_Observacao;
   String Cand_PaisRegiao;
   String Cand_Estado;
   String Cand_Cidade;
   String Cand_Bairro;
   String Cand_Rua;
    
   public CadastroCandidato2DAO(){
this.connection = new ConnectionFactory().getConnection();
    }     

    public void adiciona(CadastroCandidato2 CadastroCandidato2){ 
        String sql = "INSERT INTO Candidato(Cand_Nome,Cand_CPF,Cand_RG,Cand_DataNascimento,Cand_Sexo,Cand_TelefoneCelular,Cand_Escolaridade,Cand_Atuacao,Cand_Observacao,Cand_PaisRegiao,Cand_Estado,Cand_Cidade,Cand_Bairro,Cand_Rua) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try { 
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, CadastroCandidato2.getCand_Nome());
            stmt.setString(2, CadastroCandidato2.getCand_CPF());
            stmt.setString(3, CadastroCandidato2.getCand_RG());
            stmt.setString(4, CadastroCandidato2.getCand_DataNascimento());
            stmt.setString(5, CadastroCandidato2.getCand_Sexo());
            stmt.setString(6, CadastroCandidato2.getCand_TelefoneCelular());
            stmt.setString(7, CadastroCandidato2.getCand_Escolaridade());
            stmt.setString(8, CadastroCandidato2.getCand_Atuacao());
            stmt.setString(9, CadastroCandidato2.getCand_Observacao());
            stmt.setString(10, CadastroCandidato2.getCand_PaisRegiao());
            stmt.setString(11, CadastroCandidato2.getCand_Estado());
            stmt.setString(12, CadastroCandidato2.getCand_Cidade());
            stmt.setString(13, CadastroCandidato2.getCand_Bairro());
            stmt.setString(14, CadastroCandidato2.getCand_Rua());
            stmt.execute();
            stmt.close();
        } 
        catch (SQLException u) { 
            throw new RuntimeException(u);
        } 
        
    }

}
