/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;
import factory.ConnectionFactory;
import modelo.CadastroVaga;
import java.sql.*;
import java.sql.PreparedStatement;
/**
 *
 * @author senai
 */
public class CadastroVagaDAO {
     private Connection connection;
    long Vag_COD;
    String Vag_Nome;
    String Vag_TipoVaga;
    String Vag_TipoFuncionarioNecessario;
    String Vag_CargaHoraria;
    String Vag_PeriodoNecessario;
    String Vag_Salario;
    String Vag_Observacao;
public CadastroVagaDAO(){
this.connection = new ConnectionFactory().getConnection();
    } 
    public void adiciona(CadastroVaga CadastroVaga){ 
        String sql = "INSERT INTO Vaga (Vag_Nome,Vag_TipoVaga,Vag_TipoFuncionarioNecessario,Vag_CargaHoraria,Vag_PeriodoNecessario,Vag_Salario,Vag_Observacao) VALUES(?,?,?,?,?,?,?)";
        try { 
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, CadastroVaga.getVag_Nome());
            stmt.setString(2, CadastroVaga.getVag_TipoVaga());
            stmt.setString(3, CadastroVaga.getVag_TipoFuncionarioNecessario());
            stmt.setString(4, CadastroVaga.getVag_CargaHoraria());
            stmt.setString(5, CadastroVaga.getVag_PeriodoNecessario());
            stmt.setString(6, CadastroVaga.getVag_Salario());
            stmt.setString(7, CadastroVaga.getVag_Observacao()); 
            stmt.execute();
            stmt.close();
        } 
        catch (SQLException u) { 
            throw new RuntimeException(u);
        } 
        
    }
}
