/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import factory.ConnectionFactory;
import modelo.CadastroCandidato1;
import java.sql.*;
import java.sql.PreparedStatement;
public class CadastroCandidato1DAO {
    private Connection connection;
    String UC_Email;
    String UC_UserLogin;
    String UC_Senha;
    
public CadastroCandidato1DAO(){
this.connection = new ConnectionFactory().getConnection();
    }     

    public void adiciona(CadastroCandidato1 CadastroCandidato1){ 
        String sql = "INSERT INTO User_Candidato(UC_Email,UC_UserLogin,UC_Senha) VALUES(?,?,?)";
        try { 
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, CadastroCandidato1.getUC_Email());
            stmt.setString(2, CadastroCandidato1.getUC_UserLogin());
            stmt.setString(3, CadastroCandidato1.getUC_Senha());
            stmt.execute();
            stmt.close();
        } 
        catch (SQLException u) { 
            throw new RuntimeException(u);
        } 
        
    }

}
